![icon](https://github.com/Eschatologue/Heavy-Armaments-Industries/blob/master/HAI%20Banner%20Ex2.png)
# Heavy Armaments Industries
Merged from Heavy Armaments and Heavy Industries forming a mod that expands vanilla mindustry both arsenals and industrial aspect to offer more selection with more powerful and efficient turrets and factory

## UNFINISHED / WORK IN PROGRESS
A LOT of things are in the process of porting to V6 and im also working alone so yeah itll take sometime until this mod will work properly.

## Software Used
- **Inkscape** (For logo)
- **Visual Studio Code** (Editing JSON)
- **Piskel** (Making Sprites)

## Progress Checklist
- Somewhat playable in V6 ![progress](https://progress-bar.dev/100)
- Ready to be played in V6 ![progress](https://progress-bar.dev/28)
- Bundles [eng] ![progress](https://progress-bar.dev/100)
- Respriting Blocks ![progress](https://progress-bar.dev/96)
- Respriting Turrets ![progress](https://progress-bar.dev/60)




